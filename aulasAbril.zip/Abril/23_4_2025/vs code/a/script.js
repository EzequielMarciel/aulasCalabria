console.log("ola,mundo");
let nome = prompt("qual seu o seu nome?");
console.log("ola" + nome + "!");