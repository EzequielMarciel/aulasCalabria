var anoAtual = 2025;
var anoNascimento = prompt ('Digite o ano que nascestes.');
var idade = anoAtual - anoNascimento;
alert("sua idade é: " + idade + " anos");